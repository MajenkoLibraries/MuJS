function boot() {
    loadCode();
    fetchFiles();
    getMessages();
}

function submitCode() {
    new Ajax.Request("/setCode.ck", {
        method: "post",
        parameters: {
            sketch: $F($('sketch'))
        }
    });
}

function loadCode() {
    new Ajax.Request("/getCode.ck", {
        method: "get",
        onSuccess: function(r) {
            $('sketch').setValue(r.responseText);
        }
    });
}

function fetchFiles() {
    new Ajax.Request("/getFiles.ck", {
        method: "get",
        onSuccess: function(r) {
            $('filelist').innerHTML = r.responseText;
        }
    });
}

function mountSD() {
    new Ajax.Request("/mount.ck", {
        method: "get",
        onSuccess: function(r) {
            fetchFiles();
            reportErrors(r);
        }
    });
}

function unmountSD() {
    new Ajax.Request("/unmount.ck", {
        method: "get",
        onSuccess: function(r) {
            fetchFiles();
            reportErrors(r);
        }
    });
}

function reportErrors(r) {
    var j = r.responseJSON;
    if (j.error == false) {
        return;
    }
    $('messages').innerHTML += j.message + "\n";
    $('messages').scrollTop = $('messages').scrollHeight;
}

function getMessages() {
    new Ajax.Request("/getLog.ck", {
        method: "get",
        onSuccess: function(r) {
            $('messages').innerHTML += r.responseText;
            $('messages').scrollTop = $('messages').scrollHeight;
            setTimeout(function() { getMessages(); }, 250);
        }
    });
}
